% SRCR - 1º Exercício do trabalho de grupo

:- op( 900,xfy,'::' ).
:- dynamic(utente/4).
:- dynamic(servico/4).
:- dynamic(consulta/4).
:- dynamic fichaMedica/4.
:- dynamic doenca/2.

%--------------------Base de conhecimento com informação sobre utente, serviço e consulta --------------------------

% Extensão do predicado utente: IdUt, Nome, Idade, Cidade-> {V,F}
utente(1, 'Joao', 27, 'Braga').
utente(2, 'Davide', 14, 'Esposende').
utente(3, 'Artur', 12, 'Esposende').
utente(4, 'André', 23, 'Vila Real').
utente(5, 'Pedro', 24, 'Ponta Delgada').
utente(6, 'Helena', 20, 'Guimarães').
utente(7, 'Mariana', 6, 'Braga').
utente(8, 'Pedro', 99, 'Braga').
utente(9, 'Alexandre', 51, 'Guimarães').
utente(10, 'Adriana', 80, 'Vila Real').
utente(11, 'Diogo', 54, 'Braga').
utente(12, 'Helena', 81, 'Vila Real').
utente(13, 'André', 5, 'Bragança').
utente(14, 'Inês', 59, 'Porto').
utente(15, 'Filipa', 132, 'Braga').

% Extensão do predicado serviço: IdServ, Descrição, Instituição, Cidade -> {V,F}
servico(1, 'Pediatria', 'Hospital de Braga', 'Braga').
servico(2, 'Oncologia', 'Centro Hospitalar de Vila Nova de Gaia', 'Gaia').
servico(3, 'Dermatologia', 'Hospital da Luz', 'Lisboa').
servico(4, 'Dermatologia', 'Centro Hospitalar de Vila Nova de Gaia', 'Gaia').
servico(5, 'Pedologia', 'Hospital de Santa Maria', 'Lisboa').
servico(6, 'Ortopedia', 'Hospital de Sao Joao', 'Porto').
servico(7, 'Oncologia', 'Centro Hospitalar de Vila Nova de Gaia', 'Gaia').
servico(8, 'Ginecologia', 'Hospital Amigos do Ginas', 'Braga').

% Extensão do predicado consulta: Data, IdUt, IdServ, Custo -> {V,F}
consulta('2018-1-1',1,1,10).
consulta('2018-1-2',1,2,100).
consulta('2018-1-3',12,3,300).
consulta('2018-4-12',15,4,250).
consulta('2018-12-4',12,7,50).
consulta('2018-10-10',7,6,90).
consulta('1971-3-2',15,8,99).

% Extensao do predicado fichaMedica: IdUt, Altura, Peso, [Doença] -> {V,F}
fichaMedica(1, 1.70, 79, [1,10]).
fichaMedica(2, 1.56, 60, [4,8]).
fichaMedica(3, 1.65, 64, [2]).
fichaMedica(4, 1.63, 56 , [5]).
fichaMedica(5, 1.77, 80, [7,10]).
fichaMedica(6, 1.69, 65, [6]).
fichaMedica(7, 1.73, 65, [3]).
fichaMedica(8, 1.72, 57, [9]).
fichaMedica(9, 1.59, 58, [5]).
fichaMedica(10, 1.81, 78, [8,10]).

% Extensao do predicado doenca: IdDoenca, Nome, Tipo, Descricao -> {V,F}
doenca(1, 'Diabetes Tipo 1').
doenca(2, 'Diabetes Tipo 2').
doenca(3, 'Esclerose multipla').
doenca(4, 'Anorexia').
doenca(5, 'Epilepsia').
doenca(6, 'Sindrome de Tourette').
doenca(7, 'Osteoporose').
doenca(8, 'Ansiedade').
doenca(9, 'Cirrose').
doenca(10, 'Menopausa').
doenca(11, 'Acne').

%---------------------------Predicados Auxiliares-------------------------------------------------------

% Extensao do predicado solucoes : Termo,Questao,Solucoes -> {V,F}
solucoes(T,Q,S):- findall(T,Q,S).

% Extensao do predicado pertence: Elemento,Lista -> {V,F}
pertence(X,[X|_]).
pertence(S,[X|XS]) :- pertence(S,XS).

% Extensao do predicado soma: Lista, Resultado -> {V,F}
soma([],0).
soma([L|T],C) :- soma(T,S), C is L+S.

% Extensao do predicado comprimento: Lista, Resultado -> {V,F}
comprimento([],0).
comprimento([L|T],X) :- comprimento(T,Y), X is Y+1.

% Extensao do predicado nao : Q -> {V,F}
nao(Q) :- Q,!,fail.
nao(Q).

% Extensao do predicado apagarTodos: Elemento,Lista,Resultado -> {V,F}
apagarTodos(_,[],[]).
apagarTodos(X,[H|T],R) :- X\=H, apagarTodos(X,T,S), R = [H|S].
apagarTodos(X,[H|T],R) :- X==H, apagarTodos(X,T,R).

% Extensao do predicado removerep: Lista,Resultado -> {V,F}
removerep([],[]).
removerep([H|T],L) :- pertence(H,T), apagarTodos(H,T,S1), removerep(S1,S2), L = [H|S2].
removerep([H|T],L) :- nao(pertence(H,T)), removerep(T,S), L= [H|S].

% Extensaao do predicado repetidos :- Lista, Resultado -> {V,F}
repetidos([],0).
repetidos([X|L], N) :- pertence(L,X),
					   repetidos(L, R1),
					   N is R1 + 1.
repetidos([X|L], N) :- nao(pertence(L,X)),
					   repetidos(L, R1),
			   	   	   N is R1.

%-----------------------------------Evolucao e Involucao--------------------------------------
% Extensao do predicado evolucao : Termo -> {V,F}
evolucao(Termo) :- solucoes(Invariante,+Termo::Invariante,Lista),
				   inserir(Termo),
				   test(Lista).

% Extensao do predicado inserir : Termo -> {V,F}
inserir(Termo) :- assert(Termo).
inserir(Termo) :- retract(Termo),!,fail.

% Extensao do predicado test : T -> {V,F}
test([]).
test([H|T]) :- H, test(T).

% Extensao do predicado involucao : Termo -> {V,F}
involucao(Termo) :- solucoes(Invariante,-Termo::Invariante,Lista),
		        	test(Lista),
					remover(Termo).

% Extensao do predicado remover : Termo -> {V,F}
remover(Termo) :- retract(Termo).

%----------------------------------------Invariantes----------------------------------------------------------
% Invariantes de adicao

% Impede adição de utentes com o mesmo ID.
+utente(IdUt,_,_,_) :: (solucoes(IdUt,utente(IdUt,_,_,_),S),
						comprimento(S,X),
						X==1).

% Impede adição de serviços com o mesmo ID.
+servico(IdServ,_,_,_) :: (solucoes(IdServ,servico(IdServ,_,_,_),S),
						   comprimento(S,X),
						   X==1).

% Impede adição de serviços com a mesma Descrição e Instituição.
+servico(_,Des,Inst,_) :: (solucoes((Des,Inst),servico(_,Des,Inst,_),S),
						   comprimento(S,X),
						   X == 1).


% Impede adição de consultas com Id de Utentes que não existem.
+consulta(_,IdUt,_,_) :: (solucoes(IdUt,utente(IdUt,_,_,_),S),
						  comprimento(S,X),
						  X == 1).

% Impede adição de consultas com Id de Serviços que não existem.
+consulta(_,_,IdServ,_) :: (solucoes(IdServ,servico(IdServ,_,_,_),S),
							comprimento(S,X),
							X == 1).

% Impede adição de doenças com o mesmo ID. 
+doenca(IdDoenca,Nome) :: (solucoes(IdDoenca,(doenca(IdDoenca,_)),S),
						comprimento(S,Comp),
						Comp == 1).

% Impede adição de doenças com o mesmo nome. 
+doenca(IdDoenca,Nome) :: (solucoes(Nome,(doenca(_,Nome)),S),
						comprimento(S,Comp),
						Comp == 1).

% Impede a adição de doenças repetidas na ficha médica
+fichaMedica(IdUt, A, P, D) :: (repetidos(D, N),
								N == 0).

% Impede adição de uma ficha médica relativa a um utente que não existe
+fichaMedica(IdUt, A, P, D) :: (solucoes(IdUt,(utente(IdUt,_,_,_)),S),
								comprimento(S,Comp),
								Comp == 1).

% Impede adição de mais que uma ficha médica por utente
+fichaMedica(IdUt, A, P, D) :: (solucoes(IdUt,(fichaMedica(IdUt,_,_,_)),S),
								comprimento(S,Comp),
								Comp == 1).

% Impede adição de doenças na ficha médica de doenças inexistentes
+fichaMedica(IdUt, A, P, D) :: doencaExiste(D).

% Extensao do predicado doencaExiste : [Doenças] -> {V,F}
doencaExiste([]).
doencaExiste([X|L]) :- doenca(X,_), doencaExiste(L).



%Invariantes para remoção

% Impede remoção de utentes com IDs que não existem
-utente(IdUt,_,_,_) :: (solucoes(IdUt,utente(IdUt,_,_,_),S),
						comprimento(S,X),
						 X==1).

% Impede remoção de utentes com consultas.
-utente(IdUt,_,_,_) :: (solucoes(IdUt,consulta(_,IdUt,_,_),S),
						comprimento(S,X),
						X==0).

% Impede remoção de serviços com o IDs que não existem
-servico(IdServ,_,_,_) :: (solucoes(IdServ,servico(IdServ,_,_,_),S),
						   comprimento(S,X),
						   X==1).

% Impede remoção de serviços com consultas.
-servico(IdServ,_,_,_) :: (solucoes(IdServ,consulta(_,_,IdServ,_),S),
						   comprimento(S,X),
						   X==0).

% Impede remoção de consultas que não existam.
-consulta(Data,IdUt,IdServ,_) :: (solucoes((Data,IdUt,IdServ),consulta(Data,IdUt,IdServ,_),S),
							      comprimento(S,X),
							      X==1).

% Impede remoção de doença que não existam.
-doenca(IdDoenca,Nome) :: (solucoes((IdDoenca,Nome),doenca(IdDoenca,Nome),S),
							      comprimento(S,X),
							      X==1).

% Impede remoção de doença que exista numa ficha médica.
-doenca(IdDoenca,Nome) :: nao((fichaMedica(IdUt,_,_,D),pertence(IdDoenca,D))).


% Impede remoção de ficha médica que não existam.
-fichaMedica(IdUt, Altura, Peso, Doencas) :: (solucoes((IdUt, Altura, Peso, Doencas),fichaMedica(IdUt, Altura, Peso, Doencas),S),
							      		      comprimento(S,X),
							     			  X==1).

% Impede adição de doenças na ficha médica de doenças inexistentes
-fichaMedica(IdUt, A, P, D) :: doencaPertence(D).



%------------------------------Funcionalidades-----------------------------------

% Registar utentes, serviços, consultas, ficha medica e doenças;

% Extensao do predicado registar: T -> {V,F}
registar(T) :- evolucao(T).

% Extensao do predicado registarUtente: IdUt, Nome, Idade, Cidade -> {V,F}
registarUtente(IdUt,_,_,_) :- evolucao(utente(IdUt,_,_,_)).

% Extensao do predicado registarServico: IdServ, Descrição, Instituição, Cidade -> {V,F}
registarServico(IdServ,_,_,_) :- evolucao(servico(IdServ,_,_,_)).

% Extensão do predicado registarConsulta: Data, IdUt, IdServ, Custo -> {V,F}
registarConsulta(D,U,S,C) :- evolucao(consulta(D,U,S,C)).

% Extensão do predicado registarDoenca: IdDoenca, Nome -> {V,F}
registarDoenca(IdDoenca,Nome) :- evolucao(doenca(IdDoenca,Nome)).

% Extensão do predicado registarFichaMedica: IdUt, Altura, Peso, [Doenças] -> {V,F}
registarFichaMedica(IdUt, Altura, Peso, Doencas) :- evolucao(fichaMedica(IdUt, Altura, Peso, Doencas)).

% Remover utentes, serviços, consultas, fichas medicas e doenças;

% Extensao do predicado removerUtente: IdUt -> {V,F}
removerUtente(IdUt) :- involucao(utente(IdUt,_,_,_)).

% Extensao do predicado removerServico: IdServ -> {V,F}
removerServico(IdServ) :- involucao(servico(IdServ,_,_,_)). 

% Extensao do predicado removerConsulta: Data,IdUt,IdServ -> {V,F}
removerConsulta(Data,IdUt,IdServ) :- involucao(consulta(Data,IdUt,IdServ,_)).

% Extensao do predicado removerDoenca: IdDoenca,Nome -> {V,F}
removerDoenca(IdDoenca,Nome) :- involucao(doenca(IdDoenca,Nome)).

% Extensao do predicado removerFichaMedica: IdUt, Altura, Peso, Doencas -> {V,F}
removerFichaMedica(IdUt, Altura, Peso, Doencas) :- involucao(fichaMedica(IdUt, Altura, Peso, Doencas)).

% Identificar as instituições prestadoras de serviços;

%Extensao do predicado instServico : Instituição -> {V,F}
instServico(I) :- solucoes(Inst, servico(_,_,Inst,_), S), 
                  removerep(S,I).


% Identificar utentes/serviços/consultas por critérios de seleção;

% Extensao do predicado identUtente : IdUt,Resultado -> {V,F}
identUtente(IdUt, R) :- solucoes(Nome, utente(IdUt,Nome,_,_),R).

% Extensao do predicado identUtenteCidade : Cidade,Resultado -> {V,F}
identUtenteCidade(Cidade, R) :- solucoes((Nome,Idade), utente(_,Nome,Idade,Cidade),R).

% Extensao do predicado identUtenteNome : Nome,Resultado -> {V,F}
identUtenteNome(Nome, R) :- solucoes((Idade,Cidade), utente(_,Nome,Idade,Cidade),R).

% Extensao do predicado identServico : IdServ,Resultado -> {V,F}
identServico(IdServ, R) :- solucoes(Des, servico(IdServ,Des,_,_),R).

% Extensao do predicado identServicoDescricao : Descrição,Resultado -> {V,F}
identServicoDescricao(Des, R) :- solucoes((IdServ,Inst), servico(IdServ,Des,Inst,_),R). 

% Extensao do predicado identServicoCidade : Cidade,Resultado -> {V,F}
identServicoCidade(Cidade, R) :- solucoes((Des,Inst), servico(_,Des,Inst,Cidade),R). 

% Extensao do predicado identConsulta : IdUt,IdServ, Resultado -> {V,F}
identConsulta(IdUt, IdServ, R) :- solucoes((Data,Custo), consulta(Data, IdUt, IdServ,Custo),R).

% Extensao do predicado identConsultaData : Data,Resultado -> {V,F}
identConsultaData(Data, R) :- solucoes((IdUt,IdServ,Custo), consulta(Data, IdUt, IdServ,Custo),R).


% Identificar consulta prestados por instituição/cidade/datas/custo;

% Extensao do predicado consultaInst: Instituição,Resultado -> {V,F}
consultaInst(Inst, R) :- solucoes((Data,IdUt,IdServ,Custo), (consulta(Data,IdUt,IdServ,Custo), servico(IdServ,_,Inst,_)),R).

% Extensao do predicado consultaCid: Cidade,Resultado -> {V,F}
consultaCid(Cid, R) :- solucoes((Data,IdUt,IdServ,Custo), (consulta(Data,IdUt,IdServ,Custo), servico(IdServ,_,_,Cid)),R).

% Extensao do predicado consultaData: Data,Resultado -> {V,F}
consultaData(Data, R) :- solucoes((Data,IdUt,IdServ,Custo), consulta(Data,IdUt,IdServ,Custo), R).

% Extensao do predicado consultaCusto: Custo,Resultado -> {V,F}
consultaCusto(Custo, R) :- solucoes((Data,IdUt,IdServ,Custo), consulta(Data,IdUt,IdServ,Custo), R).


% Identificar os utentes de um serviço/instituição;
%serviço: IdServ, Descrição, Instituição, Cidade


% Extensao do predicado do utentesServ : IdUt,R -> {V,F}
utentesServ(Des, Utentes) :- solucoes(U,(servico(IdServ,Des,_,_),consulta(_,IdUt,IdServ,_),utente(IdUt,U,_,_)), Utentes).

% Extensao do predicado do utentesInst : IdUt,R -> {V,F}
utentesInst(Inst, Utentes) :- solucoes(U,(servico(IdServ,_,Inst,_),consulta(_,IdUt,IdServ,_),utente(IdUt,U,_,_)), Utentes).


% Identificar serviços realizados por utente/instituição/cidade;

% Extensao do predicado servicoUtentet: Nome,Resultado -> {V,F}
servicoUtente(Nome, R) :- solucoes((IdServ,Des,Inst,Cid), (servico(IdServ,Des,Inst,Cid), consulta(_,IdUt,IdServ,_),utente(IdUt,Nome,_,_)), R).

% Extensao do predicado servicoInst: Instituição,Resultado -> {V,F}
servicoInst(Inst, R) :- solucoes((IdServ,Des,Inst,Cid), servico(IdServ,Des,Inst,Cid), R).

% Extensao do predicado servicoCid: Cidade,Resultado -> {V,F}
servicoCid(Cid, R) :- solucoes((IdServ,Des,Inst,Cid), servico(IdServ,Des,Inst,Cid), R).

%  Calcular o custo total dos cuidados de saúde por utente/serviço/instituição/data.

% Extensao do predicado do custoUtente : IdUt,Custo -> {V,F}
custoUtente(IdUt, Custo) :- solucoes(C,consulta(_,IdUt,_,C), L),
							soma(L,Custo).
 
% Extensao do predicado do custoServico : IdServ,Custo -> {V,F}
custoServico(IdServ, Custo) :- solucoes(C,consulta(_,_,IdServ,C), L),
							   soma(L,Custo).

% Extensao do predicado do custoData : Data,Custo -> {V,F}
custoData(Data, Custo) :- solucoes(C,consulta(Data,_,_,C), L),
						  soma(L,Custo).
 
% Extensao do predicado do custoInst : Instituicão,Custo -> {V,F} 
custoInst(Inst, Custo) :- solucoes(C,(servico(IdServ,_,Inst,_),consulta(_,_,IdServ,C)),L), 
						  soma(L,Custo).

% Determinar quais as doencas de um utente

% Extensao do predicado doencasUtente : IdUtente, [Doença] -> {V,F}
doencasUtente(IdUt, D) :- fichaMedica(IdUt,_,_,Doencas),
						  nomeDoencas(Doencas, D).

% Extensao do predicado nomeDoencas : [Doencas], [Nomes] -> {V,F}
nomeDoencas([],[]).
nomeDoencas([X|L], [I|LS]) :- doenca(X,I),
							  nomeDoencas(L,LS).
