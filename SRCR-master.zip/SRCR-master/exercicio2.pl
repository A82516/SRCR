

:- set_prolog_flag( discontiguous_warnings,off ).
:- set_prolog_flag( single_var_warnings,off ).
:- set_prolog_flag( unknown,fail ).


:- op( 900,xfy,'::' ).
:- op( 900,xfy,'e' ).
:- op( 900,xfy,'ou' ).
:- dynamic utente/4.
:- dynamic prestador/5.
:- dynamic cuidado/5.
:- dynamic fichaMedica/4.
:- dynamic doenca/2.
:- dynamic (-)/1.
:- dynamic excecao/1.
:- dynamic conjuncao/3.
:- dynamic disjuncao/3.
:- dynamic nulo/1.

% ----------------------------------------------------------
% Extensão do predicado utente: idUt, Nome, Idade, Morada ↝ { 𝕍, 𝔽, 𝔻 }
utente(1, 'Joao', 27, 'Braga').
utente(2, 'Davide', 14, 'Esposende').
utente(3, 'Artur', 12, 'Esposende').
utente(4, 'André', 23, 'Vila Real').
utente(5, 'Pedro', 24, 'Ponta Delgada').
utente(6, 'Helena', 20, 'Guimarães').
utente(7, 'Mariana', 6, 'Braga').

-utente(16, 'Maria', 19, 'Mirandela').
-utente(18, 'Joao', 19, 'Albufeira').
-utente(35, 'Ricardo', 29, 'Amares').

% Admissão do pressuposto do mundo fechado para o predicado utente

-utente(Id,N,I,C) :-
    nao(utente(Id,N,I,C)),
    nao(excecao(utente(Id,N,I,C))).

% Invariante Estrutural
% Garantia de unicidade nos Ids dos utentes
+utente( IdUt,Nome,Idade,Cidade ) :: ( solucoes( (IdUt), utente(IdUt,No,I,Cid), S ),
                            comprimento( S,N ),
                            N == 0 ).

% Garante que não existe conhecimento positivo contraditótio
+(-utente( IdUt,Nome,Idade,Cidade )) :: ( solucoes( (IdUt), utente(IdUt,Nome,Idade,Cidade), S ),
                            comprimento( S,N ),
                            N == 0 ).


% Invariante Referencial
% Não é possível a remoção de utentes se houver algum cuidado para este
-utente( IdUt,Nome,Idade,Cidade ) :: ( solucoes( (IdUt),cuidado( Data,IdUt,IdPrest,Des,Custo ), S ),
                                       comprimento( S,N ),
                                       N == 0 ).

% Invariante que permite a inserção de conhecimento impreciso se não houver conhecimento incerto relativo à idade
+utente( IdUt,Nome,Idade,Cidade ) :: ( solucoes( (excecao(utente(IdUt,Nome,Idd,Cidade))),
                                      excecao(utente(IdUt,Nome,Idd,Cidade)), S ),
                                      comprimento( S,N ),
                                      N == 0 ).

% Invariante que permite a inserção de conhecimento impreciso se não houver conhecimento incerto relativo à cidade
+utente( IdUt,Nome,Idade,Cidade ) :: ( solucoes( (excecao(utente(IdUt,Nome,Idade,Cid))),
                                       excecao(utente(IdUt,Nome,Idade,Cid)), S ),
                                       comprimento( S,N ),
                                       N == 0 ).

% Invariante que impede a inserção de conhecimento positivo ou negativo acerca de conhecimento interdito sobre a idade de utentes

+utente( Id,No,I,C ) :: (solucoes( (Id,No,I,C), (utente( Id,No,xpto,C ), nulo(xpto)), S ),
                         comprimento( S,N ),
                         N == 0).

+(-utente( Id,No,I,C )) :: (solucoes( (Id,No,I,C), (utente( Id,No,xpto,C ), nulo(xpto)), S ),
                            comprimento( S,N ),
                            N == 0).

% Invariante que impede a inserção de conhecimento positivo ou negativo acerca de conhecimento interdito sobre a cidade de utentes

+utente( Id,No,I,C ) :: (solucoes( (Id,No,I,C), (utente( Id,No,I,xpto ), nulo(xpto)), S ),
                         comprimento( S,N ),
                         N == 0).

+(-utente( Id,No,I,C )) :: (solucoes( (Id,No,I,C), (utente( Id,No,I,xpto ), nulo(xpto)), S ),
                            comprimento( S,N ),
                            N == 0).

% Garantir que não se adicionam exceções relativas à idade a conhecimento perfeito positivo.
+excecao( utente(Id,No,I,C) ) :: ( nao( utente( Id,No,Idd,C ) ) ).

% Garantir que não se adicionam exceções relativas à cidade a conhecimento perfeito positivo.
+excecao( utente(Id,No,I,C) ) :: ( nao( utente( Id,No,I,Cidade ) ) ).

% Garantia da não inserção de exceções repetidas.
+(excecao(utente(Id,No,I,C))) :: ( solucoes( (excecao(utente(Id,No,I,C))), excecao(utente(Id,No,I,C)), S),
                                    comprimento(S,N),
                                    N == 0).


% Extensão do predicado prestador: IdPrest, Nome, Idade, Especialidade, Instituição ↝ { 𝕍, 𝔽, 𝔻 }
prestador(1, 'Francisco', 'Pediatria', 'Hospital de Braga').
prestador(2, 'Alexandre', 'Pedologia', 'Hospital de Santa Maria').
prestador(3, 'Maria', 'Dermatologia', 'Hospital da Luz').
prestador(4, 'Mariana', 'Dermatologia', 'Centro Hospitalar de Vila Nova de Gaia').
prestador(5, 'Pedro', 'Oncologia', 'Centro Hospitalar de Vila Nova de Gaia').
prestador(6, 'Jose',  'Ortopedia', 'Hospital de Sao Joao').
prestador(7, 'Raquel', 'Oncologia', 'Centro Hospitalar de Vila Nova de Gaia').
prestador(8, 'Paulina', 'Ginecologia', 'Hospital Amigos do Ginas').

-prestador(20, 'Claudia', 'Dermatologia', 'Hospital de Sao Joao').
-prestador(17, 'Bruna', 'Cardiologia', 'Centro Hospitalar de Vila Nova de Gaia').
-prestador(38, 'Carla', 'Ginecologia', 'Hospital de Braga').


% Admissão do pressuposto do mundo fechado para o predicado prestador

-prestador(Id,N,E,Inst) :-
    nao(prestador(Id,N,E,Inst)),
    nao(excecao(prestador(Id,N,E,Inst))).


% Garantia de unicidade nos Ids dos prestadores
+prestador(IdPrest,Nome,Especialidade,Instituicao) ::
              (solucoes((IdPrest),prestador(IdPrest,No,Esp,Inst), S ),
               comprimento( S,N ),
               N == 0 ).

% Garante que não existe conhecimento positivo contraditótio
+(-prestador(IdPrest,Nome,Especialidade,Instituicao)) ::
              (solucoes((IdPrest),prestador(IdPrest,Nome,Especialidade,Instituicao), S ),
               comprimento( S,N ),
               N == 0 ).

% Invariante Referencial
% Não é possível a remoção de prestadores se houver algum cuidado para este
-prestador( IdPrest,Nome,Especialidade,Instituicao) ::
                    ( solucoes( (IdPrest),cuidado( Data,IdUt,IdPrest,Custo ), S ),
                      comprimento( S,N ),
                      N == 0 ).


% Invariante que permite a inserção de conhecimento impreciso se não houver conhecimento incerto relativo à especialidade
+prestador( IdPrest,Nome,Esp,Inst ) :: (solucoes( (excecao(prestador(IdPrest,Nome,Esppp,Inst))),
                                        excecao(prestador(IdPrest,Nome,Esppp,Inst)), S ),
                                        comprimento( S,N ),
                                        N == 0 ).

% Invariante que permite a inserção de conhecimento impreciso se não houver conhecimento incerto relativo à instituição
+prestador( IdPrest,Nome,Esp,Inst ) :: ( solucoes( (excecao(prestador(IdPrest,Nome,Esp,Instt))),
                                         excecao(prestador(IdPrest,Nome,Esp,Instt)), S ),
                                         comprimento( S,N ),
                                         N == 0 ).


% Invariante que impede a inserção de conhecimento positivo ou negativo acerca de conhecimento interdito sobre a especialidade de prestadores

+prestador( Id,No,E,Inst ) :: (solucoes( (Id,No,E,Inst ), (prestador( Id,No,xpto,Inst ), nulo(xpto)), S ),
                               comprimento( S,N ),
                               N == 0).

+(-prestador( Id,No,E,Inst )) :: (solucoes( (Id,No,E,Inst), (prestador( Id,No,xpto,Inst), nulo(xpto)), S ),
                                  comprimento( S,N ),
                                  N == 0).

% Invariante que impede a inserção de conhecimento positivo ou negativo acerca de conhecimento interdito sobre a instituição de prestadores

+prestador( Id,No,E,Inst ) :: (solucoes( (Id,No,E,Inst ), (prestador( Id,No,E,xpto ), nulo(xpto)), S ),
                               comprimento( S,N ),
                               N == 0).

+(-prestador( Id,No,E,Inst )) :: (solucoes( (Id,No,E,Inst), (prestador( Id,No,E,xpto), nulo(xpto)), S ),
                                  comprimento( S,N ),
                                  N == 0).


% Garantir que não se adicionam exceções relativas à especialidade a conhecimento perfeito positivo.
+excecao( prestador(Id,No,E,Inst)) :: ( nao( prestador( Id,No,Espp,Inst ) ) ).

% Garantir que não se adicionam exceções relativas à instituição a conhecimento perfeito positivo.
+excecao( prestador(Id,No,E,Inst) ) :: ( nao( prestador( Id,No,E,Insttt))).

% Garantia da não inserção de exceções repetidas.
+(excecao(prestador(Id,No,E,Inst))) ::
                (solucoes((excecao(prestador(Id,No,E,Inst))),excecao(prestador(Id,No,E,Inst)), S),
                comprimento(S,N),
                N == 0).

% Extensão do predicado Data, IdUt, IdPrest, Descrição, Custo ↝ { 𝕍, 𝔽, 𝔻 }
cuidado('2018-1-1',1,1,'Consulta de urgencia',10).
cuidado('2018,2,2',1,4,'Consulta de Cardiologia',100).
cuidado('2018-1-3',12,5,'Consulta de geral',300).
cuidado('2018-4-12',15,12,'Consulta de Ortopedia',250).
cuidado('2018-12-4',12,3,'Consulta de Oncologia',50).
cuidado('2018-10-10',7,6,'Consulta de urgencia',90).
cuidado('1971-3-2',15,4,'Consulta de urgencia',99).

-cuidado('2017-03-31', 5, 3,'Consulta de Cardiologia', 13).
-cuidado('2016-08-12', 3, 4,'Consulta de urgencia', 43).


% Pressuposto Mundo Fechado para o predicado cuidado

-cuidado(D,Id,IdP,Des,C) :-
    nao(cuidado(D,Id,IdP,Des,C)),
    nao(excecao(cuidado(D,Id,IdP,Des,C))).

% Invariante Estrutural

% Apenas é possível inserir um cuidado em que o IdUt esteja registado nos Utentes e
% o IdPrest esteja registado nos Prestados
+cuidado( Data,IdUt,IdPrest,Des,Custo ) :: ( solucoes( (IdUt), utente( IdUt,Nome,Idade,Morada ), S1 ),
                                             comprimento( S1,N1 ),
                                             N1 == 1,
                                             solucoes( (IdPrest), prestador(IdPrest,Nome,Especialidade,Instituicao), S2 ),
                                             comprimento( S2,N2 ),
                                             N2 == 1 ).

% Garantir que não existe conhecimento positivo repetido
+cuidado( Data,IdUt,IdPrest,Des,Custo ) :: ( solucoes( (IdUt,IdPrest), cuidado( Data,IdUt,IdPrest,Des,Custo ), S ),
                                             comprimento( S, N ),
                                             N == 0 ).

% Invariante que permite a inserção de conhecimento impreciso se não houver conhecimento incerto relativo ao custo
+cuidado( Data,IdUt,IdPrest,Des,Custo ) :: ( solucoes( (excecao(cuidado( Data,IdUt,IdPrest,Des,C ))),
                                             excecao(cuidado( Data,IdUt,IdPrest,Des,C )), S ),
                                             comprimento( S,N ),
                                             N == 0 ).

% Invariante que permite a inserção de conhecimento impreciso se não houver conhecimento incerto relativo a descriçao
+cuidado( Data,IdUt,IdPrest,Des,Custo ) :: ( solucoes( (excecao(cuidado( Data,IdUt,IdPrest,Dess,Custo ))),
                                             excecao(cuidado( Data,IdUt,IdPrest,Dess,Custo )), S ),
                                             comprimento( S,N ),
                                             N == 0 ).

% Invariante que impede a inserção de conhecimento positivo ou negativo acerca de conhecimento interdito sobre a especialidade

+cuidado( Data,IdUt,IdPrest,Des,C ) :: (solucoes( (Data,IdUt,IdPrest,Des,C), (cuidado( Data,IdUt,IdPrest,xpto,C ), nulo(xpto)), S ),
                                        comprimento( S,N ),
                                        N == 0).

+(-cuidado( Data,IdUt,IdPrest,Des,C )) :: (solucoes( (Data,IdUt,IdPrest,Des,C), (cuidado( Data,IdUt,Des,xpto,C ), nulo(xpto)), S ),
                                           comprimento( S,N ),
                                           N == 0).

% Invariante que impede a inserção de conhecimento positivo ou negativo acerca de conhecimento interdito sobre a descrição

+cuidado( Data,IdUt,IdPrest,Des,C ) :: (solucoes( (Data,IdUt,IdPrest,Des,C), (cuidado( Data,IdUt,IdPrest,xpto,C ), nulo(xpto)), S ),
                                        comprimento( S,N ),
                                        N == 0).

+(-cuidado( Data,IdUt,IdPrest,Des,C )) :: (solucoes( (Data,IdUt,IdPrest,Des,C), (cuidado( Data,IdUt,IdPrest,xpto,C ), nulo(xpto)), S ),
                                           comprimento( S,N ),
                                           N == 0).

% Invariante que impede a inserção de conhecimento positivo ou negativo acerca de conhecimento interdito sobre o custo

+cuidado( Data,IdUt,IdPrest,Des,C ) :: (solucoes( (Data,IdUt,IdPrest,Des,C), (cuidado( Data,IdUt,IdPrest,Des,xpto ), nulo(xpto)), S ),
                                        comprimento( S,N ),
                                        N == 0).

+(-cuidado( Data,IdUt,IdPrest,Des,C )) :: (solucoes( (Data,IdUt,IdPrest,Des,C), (cuidado( Data,IdUt,IdPrest,Des,xpto ), nulo(xpto)), S ),
                                           comprimento( S,N ),
                                           N == 0).

% Garantir que não existe conhecimento positivo contraditótio
+(-cuidado( Data,IdUt,IdPrest,Des,Custo ) ) :: ( solucoes( (IdUt,IdPrest), cuidado( Data,IdUt,IdPrest,Des,Custo ), S ),
                                                 comprimento( S, N ),
                                                 N == 0 ).

% Garantir que nao se adicionaa excecoes a conhecimento perfeito positivo
+excecao( cuidado( D,IdUt,IdPrest,C ) ) :: nao( cuidado( D,IdUt,IdPrest,Des,C ) ).

% Garantir que nao se adicionaa excecoes a conhecimento perfeito positivo
+excecao( cuidado( D,IdUt,IdPrest,Des,C ) ) :: nao( cuidado( D,IdUt,IdPrest,Des,Custo ) ).


% Garantia da não inserção de exceções repetidas.
+(excecao(cuidado(D,IdUt,IdPrest,Des,C))) :: ( solucoes( (excecao(cuidado(D,IdUt,IdPrest,Des,C))), excecao(cuidado(D,IdUt,IdPrest,Des,C)),S),
                                               comprimento(S,N),
                                               N < 2).

% ---------------- INSERÇÃO DE CONHECIMENTO IMPERFEITO -----------------

% ------------------------- Imperfeito Incerto -------------------------

utente(10, 'Adriana', id001, 'Vila Real').
excecao(utente( Id,N,I,C )) :- utente( Id,N,id001,C ).

utente(14, 'Inês', 59, cid002).
excecao(utente( Id,N,I,C )) :- utente( Id,N,I,cid002 ).

prestador(9, 'Ricardo',  'Ortopedia', inst004).
excecao(prestador( Id,N,Esp,Inst ) ) :- prestador(Id,N,Esp,inst004).

prestador(16, 'Rita',  esp005, 'Hospital de Famalicao').
excecao(prestador( Id,N,Esp,Inst ) ) :- prestador(Id,N,esp005,Inst).


cuidado( dat006, 3, 5,'cirurgia', 10 ).
excecao( cuidado( D,IdUt,IdPrest,Des,C ) ) :- cuidado( dat006,IdUt,IdPrest,Des,C ).



% ------------------------- Imperfeito Impreciso -------------------------

excecao(utente( 24, 'Rosa', 50, 'Braga' )).
excecao(utente( 24, 'Rosa', 52, 'Braga' )).

excecao(utente( 142, 'Marta', 20, 'Povoa de Lanhoso' )).
excecao(utente( 142, 'Marta', 21, 'Povoa de Varzim' )).
excecao(utente( 142, 'Marta', 21, 'Povoa de Lanhoso' )).
excecao(utente( 142, 'Marta', 20, 'Povoa de Varzim' )).

excecao(utente( 32, 'Jorge', 20, 'Braga' )).
excecao(utente( 32, 'Jorge', 20, 'Esposende' )).

excecao(utente( 44, 'Jorge', C, 'Braga' )) :- C>=24, C=<27.

excecao(prestador( 143, 'Maria', 'Cardiologia', 'Hospital de Braga' )).
excecao(prestador( 143, 'Maria', 'Ortopedia', 'Hospital de Braga' )).

excecao(cuidado('29-04-2017',2,3,'consula',C)) :- C>=3, C=<17.

%--------- Imperfeito Interdito -------------------------

utente(12, 'Pacheco', 55, mo0001).
excecao( utente( Id,Nome,Idade,Morada ) ) :- utente( Id,Nome,Idade,mo0001 ).
nulo( mo0001 ).

prestador( 200,'Joaquim','Cardiologia',inst002 ).
nulo( inst002 ).
excecao( prestador( ID,N,I,C ) ) :- prestador( ID,N,I,inst002 ).

cuidado('2000-03-29', 7, pre0002,'curativo', 143 ).
excecao( cuidado( Data,IdUt,IdPrest,Des,Custo ) ) :- cuidado( Data,IdUt,pre0002,Des,Custo ).
nulo( pre0002 ).


%---------------------------Predicados Auxiliares-------------------------------------------------------

% Extensao do predicado solucoes : Termo,Questao,Solucoes -> {V,F}
solucoes(T,Q,S):- findall(T,Q,S).

% Extensao do predicado pertence: Elemento,Lista -> {V,F}
pertence(X,[X|_]).
pertence(S,[X|XS]) :- pertence(S,XS).

% Extensao do predicado soma: Lista, Resultado -> {V,F}
soma([],0).
soma([L|T],C) :- soma(T,S), C is L+S.

% Extensao do predicado comprimento: Lista, Resultado -> {V,F}
comprimento([],0).
comprimento([L|T],X) :- comprimento(T,Y), X is Y+1.

% Extensao do predicado nao : Q -> {V,F}
nao(Q) :- Q,!,fail.
nao(Q).

% Extensao do predicado apagarTodos: Elemento,Lista,Resultado -> {V,F}
apagarTodos(_,[],[]).
apagarTodos(X,[H|T],R) :- X\=H, apagarTodos(X,T,S), R = [H|S].
apagarTodos(X,[H|T],R) :- X==H, apagarTodos(X,T,R).

% Extensao do predicado removerep: Lista,Resultado -> {V,F}
removerep([],[]).
removerep([H|T],L) :- pertence(H,T), apagarTodos(H,T,S1), removerep(S1,S2), L = [H|S2].
removerep([H|T],L) :- nao(pertence(H,T)), removerep(T,S), L= [H|S].

% Extensaao do predicado repetidos :- Lista, Resultado -> {V,F}
repetidos([],0).
repetidos([X|L], N) :- pertence(X,L),
					             repetidos(L, R1),
					             N is R1 + 1.
repetidos([X|L], N) :- nao(pertence(L,X)),
					             repetidos(L, R1),
			   	        	   N is R1.

%-----------------------------------Evolucao e Involucao--------------------------------------
% Extensao do predicado evolucao : Termo -> {V,F}
evolucao(Termo) :- solucoes(Invariante,+Termo::Invariante,Lista),
				           inserir(Termo),
				           test(Lista).

% Extensao do predicado inserir : Termo -> {V,F}
inserir(Termo) :- assert(Termo).
inserir(Termo) :- retract(Termo),!,fail.

% Extensao do predicado test : T -> {V,F}
test([]).
test([H|T]) :- H, test(T).

% Extensao do predicado involucao : Termo -> {V,F}
involucao(Termo) :- solucoes(Invariante,-Termo::Invariante,Lista),
		              	test(Lista),
				          	remover(Termo).

% Extensao do predicado remover : Termo -> {V,F}
remover(Termo) :- retract(Termo).


%-------------------------------------Sistema de inferencia-------------------------------------

% Extensao do meta-predicado demo: Questao,Resposta -> {V,F}
demo( Questao,verdadeiro ) :- Questao.
demo( Questao,falso ) :- -Questao.
demo( Questao,desconhecido ) :- nao( Questao ),
                                nao( -Questao ).


% Extensao do meta-predicado demoLista: [Questao],Resposta -> {V,F}
demoLista([],[]).
demoLista([Q|QT],[R|RT]) :- demo(Q,R),
                            demoLista(QT,RT).

% Extensao do meta-predicado demoComp: [Questao],Resposta -> {V,F}

demoComp([],[]).
demoComp(Q e L, R) :- demo(Q, RQ),
                        demoComp(L, RL),
                        conjuncao(RQ,RL,R).
demoComp(Q ou L, R) :- demo(Q, RQ),
                       demoComp(L, RL),
                       disjuncao(RQ,RL,R).
demoComp(Q,R) :- demo(Q,R).


% Extensao do predicado conjuncao : R1, R2, Resposta -> {V,F}
conjuncao(verdadeiro,verddeiro,verdadeiro).
conjuncao(verdadeiro,falso,falso).
conjuncao(verdadeiro,desconhecido,desconhecido).
conjuncao(falso,verdadeiro,falso).
conjuncao(falso,falso,falso).
conjuncao(falso,desconhecido,falso).
conjuncao(desconhecido,verdadeiro,desconhecido).
conjuncao(desconhecido,falso,falso).
conjuncao(desconhecido,desconhecido,desconhecido).

% Extensao do predicado disjuncao : R1, R2, Resposta -> {V,F}
disjuncao(verdadeiro,verddeiro,verdadeiro).
disjuncao(verdadeiro,falso,verdadeiro).
disjuncao(verdadeiro,desconhecido,verdadeiro).
disjuncao(falso,verdadeiro,verdadeiro).
disjuncao(falso,falso,falso).
disjuncao(falso,desconhecido,desconhecido).
disjuncao(desconhecido,verdadeiro,verdadeiro).
disjuncao(desconhecido,falso,desconhecido).
disjuncao(desconhecido,desconhecido,desconhecido).


%----------------------------Invariantes do 1º exercico---------------------------------
% Invariantes de adicao

% Impede adição de serviços com o mesmo ID.
+servico(IdServ,_,_,_) :: (solucoes(IdServ,servico(IdServ,_,_,_),S),
						   comprimento(S,X),
						   X==1).

% Impede adição de serviços com a mesma Descrição e Instituição.
+servico(_,Des,Inst,_) :: (solucoes((Des,Inst),servico(_,Des,Inst,_),S),
						   comprimento(S,X),
						   X == 1).


% Impede adição de cuidados com Id de Utentes que não existem.
+cuidado(_,IdUt,_,_,_) :: (solucoes(IdUt,utente(IdUt,_,_,_),S),
						  comprimento(S,X),
						  X == 1).

% Impede adição de consultas com Id de prestadores que não existem.
+consulta(_,_,IdPrest,_,_) :: (solucoes(IdServ,servico(IdServ,_,_,_),S),
							comprimento(S,X),
							X == 1).

% Impede adição de doenças com o mesmo ID.
+doenca(IdDoenca,Nome) :: (solucoes(IdDoenca,(doenca(IdDoenca,_)),S),
						comprimento(S,Comp),
						Comp == 1).

% Impede adição de doenças com o mesmo nome.
+doenca(IdDoenca,Nome) :: (solucoes(Nome,(doenca(_,Nome)),S),
						comprimento(S,Comp),
						Comp == 1).

% Impede a adição de doenças repetidas na ficha medica
+fichaMedica(IdUt, A, P, D) :: (repetidos(D, N),
								N == 0).

% Impede adição de uma ficha medica relativa a um utente que não existe
+fichaMedica(IdUt, A, P, D) :: (solucoes(IdUt,(utente(IdUt,_,_,_)),S),
								comprimento(S,Comp),
								Comp == 1).

% Impede adição de mais que uma ficha medica por utente
+fichaMedica(IdUt, A, P, D) :: (solucoes(IdUt,(fichaMedica(IdUt,_,_,_)),S),
								comprimento(S,Comp),
								Comp == 1).

% Impede adição de doenças na ficha medica de doenças inexistentes
+fichaMedica(IdUt, A, P, D) :: doencaExiste(D).

% Extensao do predicado doencaExiste : [Doenças] -> {V,F}
doencaExiste([]).
doencaExiste([X|L]) :- doenca(X,_), doencaExiste(L).



%Invariantes para remoção

% Impede remoção de utentes com IDs que não existem
-utente(IdUt,_,_,_) :: (solucoes(IdUt,utente(IdUt,_,_,_),S),
						comprimento(S,X),
						 X==1).

% Impede remoção de utentes com cuidados
-utente(IdUt,_,_,_) :: (solucoes(IdUt,cuidado(_,IdUt,_,_,_),S),
						comprimento(S,X),
						X==0).

% Impede remoção de serviços com o IDs que não existem
-servico(IdServ,_,_,_) :: (solucoes(IdServ,servico(IdServ,_,_,_),S),
						   comprimento(S,X),
						   X==1).

% Impede remoção de serviços com consultas.
-servico(IdServ,_,_,_) :: (solucoes(IdServ,consulta(_,_,IdServ,_),S),
						   comprimento(S,X),
						   X==0).

% Impede remoção de consultas que não existam.
-cuidado(Data,IdUt,IdServ,_,_) :: (solucoes((Data,IdUt,IdServ),consulta(Data,IdUt,IdServ,_,_),S),
							      comprimento(S,X),
							      X==1).

% Impede remoção de doença que não existam.
-doenca(IdDoenca,Nome) :: (solucoes((IdDoenca,Nome),doenca(IdDoenca,Nome),S),
							      comprimento(S,X),
							      X==1).

% Impede remoção de doença que exista numa ficha medica.
-doenca(IdDoenca,Nome) :: nao((fichaMedica(IdUt,_,_,D),pertence(IdDoenca,D))).


% Impede remoção de ficha medica que não existam.
-fichaMedica(IdUt, Altura, Peso, Doencas) :: (solucoes((IdUt, Altura, Peso, Doencas),fichaMedica(IdUt, Altura, Peso, Doencas),S),
							      		      comprimento(S,X),
							     			  X==1).

% Impede adição de doenças na ficha medica de doenças inexistentes
-fichaMedica(IdUt, A, P, D) :: doencaPertence(D).
